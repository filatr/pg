-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Июн 09 2019 г., 11:53
-- Версия сервера: 10.1.38-MariaDB
-- Версия PHP: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `poligon`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `name`, `author`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Nihil consequuntur quia vitae.', 'Ms. Maritza Corkery II', 'Quisquam eum ad qui assumenda. Dignissimos sunt fugiat ea voluptas. Deleniti minus aut magni numquam. Ut id voluptatem itaque qui odit aut.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(2, 'Eum accusantium sint adipisci aut hic dolor facere.', 'Dr. Chadd Reinger DDS', 'Non nobis nesciunt nostrum doloribus nam. Est fuga aut rerum eaque nam quis sed. Necessitatibus aut at alias dolore quasi vel repudiandae.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(3, 'Molestias modi ipsa harum magni qui ex.', 'Toy Zboncak', 'Quis cum cupiditate similique soluta. Eos voluptas quod ut quidem eum. Tempora dolore quis deserunt ipsam quidem.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(4, 'Maxime mollitia suscipit culpa.', 'Pearlie Hintz', 'Qui velit sequi deleniti sunt voluptas. Quos nobis perferendis totam temporibus cum et consequuntur. Id voluptate illum voluptatem.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(5, 'Qui natus maxime enim error aliquam rerum.', 'Miss Cynthia Schaefer', 'Amet et voluptatem deserunt sapiente tenetur consequatur consequatur. Amet ut ea alias sint. Neque nihil exercitationem aut sequi neque.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(6, 'Praesentium nemo id fugiat natus laboriosam.', 'Dr. Curt Ward', 'Nihil ut consequatur beatae consequatur ea. Nihil eum commodi est vel iste qui. Tempora molestiae quod eligendi est.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(7, 'Accusantium sequi recusandae nihil iste.', 'Caleb Schmitt', 'Repellat blanditiis autem labore sint repudiandae suscipit. Voluptatem et iure adipisci velit earum. Nesciunt quos ut aut molestiae qui.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(8, 'Similique molestiae veritatis fuga.', 'Zoila Mueller', 'Inventore consequatur voluptatem corrupti. Accusantium dolor beatae eum eaque pariatur. Nulla possimus laboriosam quia ipsum dolor sit aut. Dolores fugit provident quod illum.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(9, 'Asperiores fugit impedit beatae.', 'Hildegard Hoeger', 'Iste iusto libero repellendus. Reiciendis porro possimus error quisquam eum voluptatum. Modi est perferendis nobis exercitationem.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(10, 'Ut sunt modi perferendis exercitationem omnis sunt.', 'Alek Ondricka', 'Sunt error labore nemo aliquam laudantium voluptatem. Possimus vel consequatur dolore ea nam. Ut quis commodi nemo aut maxime aut. Laborum autem quas eius laboriosam.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(11, 'Similique dignissimos dolorum labore aspernatur.', 'Antonina Bruen', 'Magnam sunt quibusdam veritatis quo. Qui vero tempore doloremque rerum accusamus animi odio. Officia laborum ut tempora esse modi deserunt incidunt.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(12, 'Sint suscipit ea est et a quia.', 'Prof. Riley Parisian IV', 'Officia rem voluptas qui fuga beatae quas enim. Rerum iste ab nesciunt laudantium voluptatem consequatur sint. Distinctio quaerat voluptas soluta perspiciatis velit.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(13, 'Id et amet cum rerum rerum.', 'Prof. Garrison Bartoletti V', 'Necessitatibus id culpa et sequi illum dolorum aliquam. Dolore ut rerum quis eum. Ratione nisi necessitatibus sequi quis.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(14, 'Sit consequatur ut reprehenderit quia mollitia quaerat facilis.', 'Nash Jast', 'Natus cumque maxime et odio expedita. Vitae ab sed alias sed beatae. Et quos quia ut iure amet. Ex explicabo quidem eligendi sit voluptate tenetur. Et optio accusamus voluptatem.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(15, 'Culpa placeat soluta sit et necessitatibus voluptas consequatur facilis.', 'Hulda Kunde', 'In delectus consectetur reiciendis accusantium consequuntur. Totam et rerum sunt officiis reiciendis eius. Vitae architecto sequi fugit minus assumenda et.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(16, 'Qui tempora et quaerat quisquam dolorum.', 'Connor Moore', 'Sint est temporibus autem enim. Cupiditate dolores repellat animi at quia consequatur neque. Autem molestias dolorum sapiente et eveniet quos. Dolorem quam ut sed quod libero et qui.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(17, 'Qui odit velit asperiores explicabo illo.', 'Mr. Sidney Orn', 'Harum vel consequatur quis. Sunt amet accusantium similique. Aut quibusdam et quia. Labore sapiente delectus sit eligendi quasi. Aut distinctio nisi facere ut.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(18, 'Eum itaque reprehenderit est possimus sed.', 'Jena Lowe', 'Non debitis et velit eum. Repudiandae aspernatur et magnam quas maiores amet aut nobis. Labore explicabo quis voluptas qui eum et veniam maxime. Est voluptatem nisi vitae quidem.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(19, 'Perferendis delectus nisi asperiores.', 'Jovani Fahey', 'Totam consequatur est autem. Modi eius sed quos porro sit voluptatem. Perspiciatis voluptate porro aspernatur similique debitis culpa ut repellendus. Molestias facere incidunt porro facilis dolor in.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(20, 'Facilis sint cum mollitia ut voluptates est.', 'Kieran Schmeler', 'Vero dolorem autem molestias dolores. Corrupti nam mollitia id sed. Beatae sunt tempore nisi iusto. Ipsa exercitationem vel voluptatem soluta neque magnam eum.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(21, 'Minus id et omnis iure ea similique.', 'Deborah Gulgowski', 'Illo eveniet vero saepe reprehenderit magni. Deserunt laborum quod et dolore quisquam commodi voluptatum. In rerum rerum nesciunt blanditiis reprehenderit.', '2019-06-01 09:37:43', '2019-06-01 09:37:43'),
(22, 'Eligendi rerum dicta minus molestiae rem qui.', 'Jasper Bernier', 'Voluptas velit impedit nihil excepturi enim et sint. Porro omnis quos exercitationem. Quo optio et natus sunt.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(23, 'Reiciendis modi iure beatae voluptas error est aut.', 'Kyle West', 'In aperiam voluptatem dolore voluptatum qui commodi. Architecto porro quia dolor eum tempore fugiat. Et et possimus quo facilis voluptate.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(24, 'Qui corrupti cum sequi suscipit sint.', 'Carissa Gislason III', 'Id deleniti enim sint sint. Alias similique numquam perferendis quia est et. Error culpa minima velit.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(25, 'Velit sed ipsum porro porro enim et.', 'Grace Farrell V', 'Dolore aspernatur quibusdam incidunt. Cum earum et molestiae vel. Molestias quas aut error fugit. Eligendi facilis sed officia quisquam non quam.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(26, 'Soluta aut sed facere sit expedita dolor explicabo.', 'Jayde Jacobs', 'Consequatur ea iusto sapiente labore minus. Eveniet quas sunt ratione eaque et odio.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(27, 'Corrupti omnis nulla corrupti odit facilis aut at.', 'Miss Glenda Rempel II', 'Itaque ut eum aperiam sed. Quisquam asperiores quia voluptatem vel. Vero expedita voluptatem exercitationem qui atque ut unde.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(28, 'Dicta omnis ut repellendus non repellat suscipit.', 'Aubree Koepp DDS', 'Culpa optio porro nihil quisquam reprehenderit. Itaque at velit ab veritatis sit magnam quos. Illo laudantium aut dolorem accusamus sint. Velit enim doloremque quas sit quam saepe ipsum.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(29, 'Maiores cum error incidunt aut provident perferendis ut.', 'Buddy Cummerata', 'Modi omnis omnis non. Unde est error ipsa fugiat in quo. Explicabo occaecati nulla eius soluta quasi id amet. Inventore aut voluptatem eum sit itaque.', '2019-06-01 09:37:44', '2019-06-01 09:37:44'),
(30, 'Vel assumenda quo cum repellat.', 'Eudora Rolfson', 'Veritatis aliquam illo enim vel. Debitis voluptatem cum iure delectus illum. Vel non tempore possimus quos eaque sunt est.', '2019-06-01 09:37:44', '2019-06-01 09:37:44');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2019_05_30_172238_articles', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', '$2y$10$22kAAN/WM3v/uDbHYFLfSu/Mig3Llh/qSSmbobBEhFiq8H3L03wxK', 'admin', NULL, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
